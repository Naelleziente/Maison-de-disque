
document.getElementById('search').addEventListener('input', function() {
    const searchQuery = this.value.toLowerCase();
    const tracks = document.querySelectorAll('.track');
    tracks.forEach(track => {
        const title = track.querySelector('h3').textContent.toLowerCase();
        if (title.includes(searchQuery)) {
            track.style.display = 'block';
        } else {
            track.style.display = 'none';
        }
    });
});
